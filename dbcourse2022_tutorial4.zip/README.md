# dbcourse2022_tutorial5
Run the file from dbcourse2022_tutorial directory as either `python sqlite/data_to_psql_db.py)` or `python postgresql/data_to_psql_db.py`